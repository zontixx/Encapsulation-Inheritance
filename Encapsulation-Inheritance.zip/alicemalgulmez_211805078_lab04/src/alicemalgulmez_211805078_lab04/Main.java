package alicemalgulmez_211805078_lab04;
// Class 1 : CommisionEmployee
class CommisionEmployee {
    private String firstName;
    private String lastName;
    private String socialSecurityNumber;
    private double grossSales;
    private double commisionRate;
    public CommisionEmployee(String firstName, String lastName, String socialSecurityNumber, double grossSales,
            double commisionRate) throws Exception {
        this.firstName = firstName;
        this.lastName = lastName;
        this.socialSecurityNumber = socialSecurityNumber;
        if (grossSales >= 0) {
            this.grossSales = grossSales;
        } else {
            throw new Exception("Invalid Gross sales");
        }
        if (commisionRate > 0 && commisionRate < 1) {
            this.commisionRate = commisionRate;
        } else {
            throw new Exception("Invalid commision Rate");
        }
    }
    // getting and returning the informations
    public String getFirstName() {
        return firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public String getSocialSecurityNumber() {
        return socialSecurityNumber;
    }
    public double getGrossSales() {
        return grossSales;
    }
    public double getCommisionRate() {
        return commisionRate;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public void setSocialSecurityNumber(String socialSecurityNumber) {
        this.socialSecurityNumber = socialSecurityNumber;
    }
    public void setGrossSales(double grossSales) throws Exception {
        if (grossSales >= 0) {
            this.grossSales = grossSales;
        } else {
            throw new Exception("Invalid Gross sales");
        }
    }

    public void setCommisionRate(double commisionRate) throws Exception {
        if (commisionRate > 0 && commisionRate < 1) {
            this.commisionRate = commisionRate;
        } else {
            throw new Exception("Invalid commision Rate");
        }
    }

    @Override
    public String toString() {
        String result = "First name: " + firstName + "\nLast name: " + lastName + "\nSocial security number: "
                + socialSecurityNumber;
        result += String.format("\nGross sales: %.2f\nCommision rate: %.2f", grossSales, commisionRate);
        return result;
    }

}
//Class 2 : BasePlusCommisionEmployee
class BasePlusCommisionEmployee extends CommisionEmployee {
    private String firstName;
    private String lastName;
    private String socialSecurityNumber;
    private double grossSales;
    private double commisionRate;
    private double baseSalary;

    public BasePlusCommisionEmployee(String firstName, String lastName, String socialSecurityNumber, double grossSales,
            double commisionRate, double baseSalary) throws Exception {
        super(firstName, lastName, socialSecurityNumber, grossSales, commisionRate);
        if (baseSalary >= 0) {
            this.baseSalary = baseSalary;
        } else {
            throw new Exception("Invalid base Salary");
        }
    }
    public double getBaseSalary() {
        return baseSalary;
    }
    public void setBaseSalary(double baseSalary) throws Exception {
        if (baseSalary >= 0) {
            this.baseSalary = baseSalary;
        } else {
            throw new Exception("Invalid base Salary");
        }
    }
    public double earnings() {
        return (baseSalary + (getGrossSales() * getCommisionRate()));
    }

    @Override
    public String toString() {
        return super.toString() + String.format("\nBase salary: %.2f", baseSalary);
    }
}


public class Main {
    public static void main(String[] args) {
        try {
            BasePlusCommisionEmployee basePlusCommisionEmployee = new BasePlusCommisionEmployee("Lewis", "Hamilton",
                    "444-44-4444", 5000, 0.04, 300);
            System.out.println("Employee information obtained by get methods and earnings:");
            System.out.println("First name: " + basePlusCommisionEmployee.getFirstName());
            System.out.println("Last name: " + basePlusCommisionEmployee.getLastName());
            System.out.println("Social Security number: " + basePlusCommisionEmployee.getSocialSecurityNumber());
            System.out.printf("Gross sales: %.2f", basePlusCommisionEmployee.getGrossSales());
            System.out.printf("\nCommission rate: %.2f", basePlusCommisionEmployee.getCommisionRate());
            System.out.printf("\nBase salary:\n", basePlusCommisionEmployee.getBaseSalary());
            System.out.printf("Earnings: %.2f\n", basePlusCommisionEmployee.earnings());
            basePlusCommisionEmployee.setBaseSalary(1000);
            System.out.println("\nUpdated employee information obtained by toString and earings:");
            System.out.println(basePlusCommisionEmployee.toString());
            System.out.printf("Earnings: %.2f\n", basePlusCommisionEmployee.earnings());
        } 
        catch (Exception e) {
            e.printStackTrace();
        }
        // 211805078 | Ali Cemal GÜLMEZ 
    }
}